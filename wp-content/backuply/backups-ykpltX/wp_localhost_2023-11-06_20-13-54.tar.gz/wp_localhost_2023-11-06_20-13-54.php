<?php exit();?>
{
    "name": "wp_localhost_2023-11-06_20-13-54",
    "backup_dir": 0,
    "backup_db": "1",
    "email": "sinrec@yandex.ru",
    "date_time": "2023-11-06 20:13:pm",
    "btime": 1699301634,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "http:\/\/localhost\/inav",
    "backup_site_path": "\/Users\/sveta\/localhost\/inav"
}