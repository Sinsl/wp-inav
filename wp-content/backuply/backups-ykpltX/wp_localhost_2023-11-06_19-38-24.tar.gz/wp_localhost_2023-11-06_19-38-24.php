<?php exit();?>
{
    "name": "wp_localhost_2023-11-06_19-38-24",
    "backup_dir": 0,
    "backup_db": "1",
    "email": "sinrec@yandex.ru",
    "date_time": "2023-11-06 19:38:pm",
    "btime": 1699299504,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "http:\/\/localhost\/inav",
    "backup_site_path": "\/Users\/sveta\/localhost\/inav"
}