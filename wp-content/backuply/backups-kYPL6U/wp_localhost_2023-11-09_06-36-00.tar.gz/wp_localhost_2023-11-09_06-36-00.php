<?php exit();?>
{
    "name": "wp_localhost_2023-11-09_06-36-00",
    "backup_dir": 0,
    "backup_db": "1",
    "email": "sinrec@yandex.ru",
    "date_time": "2023-11-09 06:36:am",
    "btime": 1699511760,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "http:\/\/localhost\/inav",
    "backup_site_path": "\/Users\/home\/Sites\/inav"
}